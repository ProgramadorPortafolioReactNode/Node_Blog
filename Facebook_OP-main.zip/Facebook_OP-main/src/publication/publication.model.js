import mongoose from "mongoose";

const PublicationSchema = mongoose.Schema({
    title: {
        type: String,
        required: [true, "Title is required"]
    },
    programmingLanguage: {
        type: String,
        required: [true, "Programming language is required"]
    },
    content: {
        type: String,
        required: [true, "Content is required"]
    },
    imageUrl: {
        type: String,
        default: ""
    },

    commentBy: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Comment'
        }
    ],
    state: {
        type: Boolean,
        default: true
    }
});

export default mongoose.model('Publication', PublicationSchema);

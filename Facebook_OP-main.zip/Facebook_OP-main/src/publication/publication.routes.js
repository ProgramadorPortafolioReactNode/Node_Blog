import { Router } from "express";
import { check } from "express-validator";

import {
    createPublication,
    deletePublication,
    getPublication,
    updatePublication,
} from '../publication/publication.controller.js'

import { validarCampos } from "../middlewares/validar-campos.js"
//import { validarJWT } from "../middlewares/validar-jwt.js";

const router = Router();

// Obtener todas las publicaciones
router.get("/", getPublication);

// Crear una nueva publicación
router.post(
    "/",
    [
        check("title", "El título es requerido").not().isEmpty(),
        check("programmingLanguage", "El lenguaje de programación es requerido").not().isEmpty(),
        check("content", "El contenido es requerido").not().isEmpty(),
        check("imageUrl", "La URL de la imagen es requerida").isURL(),
        validarCampos
    ],
    
    createPublication
);

// Actualizar una publicación
router.put(
    "/:id",
    
    updatePublication
);

// Eliminar una publicación
router.delete(
    "/:id",
    
    deletePublication
);

export default router;

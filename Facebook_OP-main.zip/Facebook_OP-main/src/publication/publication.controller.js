import { response, request } from "express";
import Publication from './publication.model.js';

// Crear una nueva publicación
export const createPublication = async (req, res) => {
    const { title, programmingLanguage, content, imageUrl } = req.body;

    try {
        const publication = new Publication({ title, programmingLanguage, content, imageUrl });

        await publication.save();

        res.status(201).json({
            msg: 'Publicación creada correctamente',
            publication
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            msg: 'Error interno del servidor'
        });
    }
}

// Obtener todas las publicaciones
export const getPublication = async (req = request, res = response) => {
    try {
        const publications = await Publication.find({ state: true });

        res.status(200).json({
            publications
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            msg: 'Error interno del servidor'
        });
    }
}

// Actualizar una publicación
export const updatePublication = async (req, res = response) => {
    const { id } = req.params;
    const { title, programmingLanguage, content, imageUrl } = req.body;

    try {
        const publication = await Publication.findByIdAndUpdate(id, { title, programmingLanguage, content, imageUrl }, { new: true });

        if (!publication) {
            return res.status(404).json({
                msg: 'Publicación no encontrada'
            });
        }

        res.status(200).json({
            msg: 'Publicación actualizada correctamente',
            publication
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            msg: 'Error interno del servidor'
        });
    }
};

// Eliminar una publicación
export const deletePublication = async (req, res) => {
    const { id } = req.params;

    try {
        const publication = await Publication.findByIdAndUpdate(id, { state: false }, { new: true });

        if (!publication) {
            return res.status(404).json({
                msg: 'Publicación no encontrada'
            });
        }

        res.status(200).json({
            msg: 'Publicación eliminada correctamente',
            publication
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            msg: 'Error interno del servidor'
        });
    }
}


import Publication from '../publication/publication.model.js'



export const existePublicationById = async (id = '') => {
    const existePublication = await Publication.findById(id);

    if(!existePublication) {
        throw new Error(`The id : ${id} Does not exist`)
    }
}